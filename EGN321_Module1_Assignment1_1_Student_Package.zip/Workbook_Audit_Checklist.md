# Workbook Audit Checklist
## EGN 321 — Module 1

### Understand the Artifact
- [ ] What task does the workbook perform?
- [ ] What does one row represent?
- [ ] Which cells are inputs?
- [ ] Which cells are calculated?
- [ ] Where is the final output?
- [ ] What units are expected?

### Inspect Formulas
- [ ] Are formulas consistent from row to row?
- [ ] Do any formulas contain unexplained numeric constants?
- [ ] Are all expected rows included in totals or ranges?
- [ ] Are references correct?
- [ ] Does any formula differ from neighboring formulas without a reason?

### Inspect Units and Source Values
- [ ] Does every important numeric value have a unit?
- [ ] Are source notes and worksheet units consistent?
- [ ] Has any value been copied without converting units?
- [ ] Do values look physically reasonable?

### Trace the Final Result
- [ ] Start at the final result and work backward.
- [ ] Identify every input that contributes to it.
- [ ] Confirm that no populated data is silently excluded.
- [ ] Compare intermediate values with source records when available.

### Evaluate Each Suspected Defect
For every issue, ask:
1. Where is it?
2. What evidence shows it is wrong?
3. What should the correct behavior be?
4. What is the impact?
5. How can the correction be verified?
6. How long might the defect have existed?
